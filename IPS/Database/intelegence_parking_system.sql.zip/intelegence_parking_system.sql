-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 30, 2016 at 03:36 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `intelegence_parking_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `booked_parking_slots`
--

CREATE TABLE `booked_parking_slots` (
  `booking_id` int(100) NOT NULL auto_increment,
  `parking_id` int(100) NOT NULL,
  `slot_no` int(100) NOT NULL,
  `rate` int(100) NOT NULL,
  `b_date` date NOT NULL,
  `b_by` varchar(100) NOT NULL,
  PRIMARY KEY  (`booking_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `booked_parking_slots`
--

INSERT INTO `booked_parking_slots` (`booking_id`, `parking_id`, `slot_no`, `rate`, `b_date`, `b_by`) VALUES
(2, 1111, 1111, 11111, '2016-01-08', 'aaaaa'),
(4, 1, 147, 50, '2019-09-09', 'ggfgf'),
(5, 1, 12, 2000, '1995-11-12', 'n'),
(6, 1, 265, 50000, '2016-01-09', 'hyy'),
(7, 1, 12, 5000, '2016-01-01', 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `hint_question` varchar(50) NOT NULL,
  `hint_answer` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--


-- --------------------------------------------------------

--
-- Table structure for table `parking_chart`
--

CREATE TABLE `parking_chart` (
  `parcking_chart_id` int(100) NOT NULL auto_increment,
  `parking_id` varchar(100) NOT NULL,
  `slot_no` int(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY  (`parcking_chart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `parking_chart`
--

INSERT INTO `parking_chart` (`parcking_chart_id`, `parking_id`, `slot_no`, `status`) VALUES
(3, '12311111', 12, 'abc');

-- --------------------------------------------------------

--
-- Table structure for table `parking_details`
--

CREATE TABLE `parking_details` (
  `parking_id` int(50) NOT NULL auto_increment,
  `parking_name` varchar(50) NOT NULL,
  `area_name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(100) NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `owner_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`parking_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `parking_details`
--

INSERT INTO `parking_details` (`parking_id`, `parking_name`, `area_name`, `address`, `city`, `contact_no`, `owner_name`) VALUES
(2, 'fef', 'afw', 'afe', 'gwff', '412', 'gvtcdv'),
(4, 'tx', 'urytyt', 'ghifzf', 'qwer', '1478965', 'jhgfdsa'),
(5, 'ngddcsha', 'ahcjasc', 'amhgjsa', 'udhwau', '48451', 'tfcagsvc'),
(6, 'ngddcsha', 'ahcjasc', 'amhgjsa', 'udhwau', '48451', 'tfcagsvc'),
(7, 'abc', 'ahcjasc', 'afe', 'nipani', '47896512', 'surajjjjjj'),
(8, 'ngddcsha', 'ahcjasc', 'afe', 'nipani', '22623232211', 'nvc'),
(9, 'ngddcsha', 'ahcjasc', 'afe', 'nipani', '22623232211', 'nvc'),
(10, 'ngddcsha', 'xyz', 'mahadeva galli', 'nipani', '47896512', 'surajjjjjj'),
(11, 'ngddcsha', 'ahcjasc', 'mahadeva galli', 'nipani', '9632278106', 'surajjjjjj'),
(12, 'xyz', 'nipani', 'mahadeva galli', 'udhwau', '47896512', 'surajjjjjj'),
(14, 'abc', 'xyz', 'mahadeva galli', 'ert', '1445', 'surajjjjjj');

-- --------------------------------------------------------

--
-- Table structure for table `parking_fecility`
--

CREATE TABLE `parking_fecility` (
  `parking_fecility_id` int(50) NOT NULL auto_increment,
  `parking_id` varchar(50) NOT NULL,
  `fecility_name` varchar(50) NOT NULL,
  `discription` varchar(50) NOT NULL,
  PRIMARY KEY  (`parking_fecility_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `parking_fecility`
--

INSERT INTO `parking_fecility` (`parking_fecility_id`, `parking_id`, `fecility_name`, `discription`) VALUES
(3, '12', 'jyfsu', 'agyusv'),
(4, '12', 'abc', 'ybdesvcbbh');

-- --------------------------------------------------------

--
-- Table structure for table `parking_rates`
--

CREATE TABLE `parking_rates` (
  `parking_id` int(50) NOT NULL,
  `rate_id` int(50) NOT NULL auto_increment,
  `rate` varchar(50) NOT NULL,
  `monthly_pass` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  PRIMARY KEY  (`rate_id`),
  UNIQUE KEY `parking_id` (`parking_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `parking_rates`
--

INSERT INTO `parking_rates` (`parking_id`, `rate_id`, `rate`, `monthly_pass`, `status`) VALUES
(12311111, 1, '11111', '96559875', 'xyzzzzzz'),
(1111, 2, '11111', '9655', 'abc'),
(1245, 3, '00', '00', 'xyzzzzzz');

-- --------------------------------------------------------

--
-- Table structure for table `service_station_details`
--

CREATE TABLE `service_station_details` (
  `ser_stan_id` int(50) NOT NULL auto_increment,
  `ser_stan_name` varchar(50) NOT NULL,
  `ser_stan_type` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `fecilities` varchar(50) NOT NULL,
  PRIMARY KEY  (`ser_stan_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `service_station_details`
--

INSERT INTO `service_station_details` (`ser_stan_id`, `ser_stan_name`, `ser_stan_type`, `address`, `city`, `state`, `contact_no`, `fecilities`) VALUES
(2, 'null', 'null', 'jyDU', 'AYDGAJS', 'kfgifye', '6165518', 'acsgjca'),
(5, 'null', 'null', 'ghi', 'nipani', 'ghv', '1445', 'aewfeff'),
(6, 'ggs', 'hgcvdc', 'ghi', 'nipani', 'frsc', '1445', 'aewfeff'),
(7, 'saszdddf', 'afas', 'ghi', 'nipani', 'frsc', '1445', 'aewfeff'),
(8, 'saszdddf', 'afas', 'ghi', 'nipani', 'frsc', '1445', 'aewfeff');

-- --------------------------------------------------------

--
-- Table structure for table `user_registration`
--

CREATE TABLE `user_registration` (
  `user_id` int(50) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `user_type` varchar(100) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user_registration`
--

INSERT INTO `user_registration` (`user_id`, `name`, `address`, `contact_no`, `city`, `state`, `user_type`) VALUES
(1, 'vinu', 'swd', '8123467148', 'nipani', 'karnataka', 'asczcd'),
(3, 'suraj', 'mahadeva galli', '9632278106', 'nipani', 'karnataka', 'gvsh');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle_details`
--

CREATE TABLE `vehicle_details` (
  `vehicle_id` int(50) NOT NULL auto_increment,
  `user_id` varchar(50) NOT NULL,
  `vehicle_name` varchar(50) NOT NULL,
  `vehicle_type` varchar(50) NOT NULL,
  PRIMARY KEY  (`vehicle_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `vehicle_details`
--

INSERT INTO `vehicle_details` (`vehicle_id`, `user_id`, `vehicle_name`, `vehicle_type`) VALUES
(1, '60', 'maruti', '800'),
(3, '1', 'maruti', '801');
